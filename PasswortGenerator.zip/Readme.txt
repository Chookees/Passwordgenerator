This is a Program i created to Generate pretty safe passwords.

The Strength counter is working by 4 steps.
step one:   From 0-3  = Only Lowcase letters.
Step two:   From 3-6  = Lowletter and Upcase letter.
Step three: From 6-8  = Lowletter, Upcase, and Numbers.
Step four:  From 8-10 = lowletter, upcase, numbers, and special character.

The password is beeing saved (if you want it to) in a txt file, that will be created (in the future) 
where you want. For now it is created in the debug folder.

The password will be automatically copied to the clipboard.

This is verion 1.0.0

Greets,
A.Bobb